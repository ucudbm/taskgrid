#!/usr/bin/env bash
ping -c 1 localhost
